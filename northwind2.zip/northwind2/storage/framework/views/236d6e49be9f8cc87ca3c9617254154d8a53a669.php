

<?php $__env->startSection('content'); ?>


<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Company Name</th>
        <th scope="col">Contact Name</th>
        <th scope="col">Contact Title</th>
      </tr>
    </thead>

    <tbody>
        <?php
            $bill=1;
        ?>
        <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scope="row"><?php echo e($bill++); ?></th>
            <td><?php echo e($item->CompanyName??''); ?></td>
            <td><?php echo e($item->ContactName??''); ?></td>
            <td><?php echo e($item->ContactTitle??''); ?></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
</table>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwind2\resources\views/query/index.blade.php ENDPATH**/ ?>