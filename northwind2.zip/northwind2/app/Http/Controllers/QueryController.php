<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QueryController extends Controller
{
    //

    public function queryBuilder() {

        $d['model']=DB::table('customers')
                    ->select('CompanyName','ContactName','ContactTitle')
                    ->get();

                    
        dd($d['model']);

        return view('query.index',$d);
    }
}
